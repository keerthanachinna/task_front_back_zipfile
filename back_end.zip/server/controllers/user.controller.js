const mongoose = require('mongoose');

const User = mongoose.model('User');
const Order = mongoose.model('Order');


module.exports.useradd = (req, res, next) => {
    var user = new User();
    user.userid = req.body.userid;
    user.name = req.body.name;
    user.save((err, doc) => {
        if (!err)
            res.send(doc);
        else return next(err);
    });
}
module.exports.orderadd = (req, res, next) => {
    var user = new Order();
    user.orderid = req.body.orderid;
    user.subtotal = req.body.subtotal;
    user.userid = req.body.userid;
    user.date = req.body.date;
    user.save((err, doc) => {
        if (!err)
            res.send(doc);
        else return next(err);
    });
}
module.exports.orderlist = (req, res, next) => {
   Order.find((err,doc)=>{
    if(!err)  res.send(doc);
    else {console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2));} 
   })
}
module.exports.userlist = (req, res, next) => {
    User.find((err,doc)=>{
        if(!err)  res.send(doc);
        else {console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2));} 
    })
 }
 
module.exports.userOrdecount = (req, res, next) => {
    Order.aggregate({$match: {userid:{$eq:req.body.userid}}},{$count: "userid"},(err,doc)=>{
        if(!err)  res.send(doc);
        else {console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2));} 
    });
}

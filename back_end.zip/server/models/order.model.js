
const mongoose = require('mongoose');

var orderSchema = new mongoose.Schema({
    orderid: {
        type: Number,
        unique: true
    },
    userid: {
        type: Number
    },
    subtotal: {
        type: Number,
    },
    date: {
        type: String,
    }
});


mongoose.model('Order', orderSchema);
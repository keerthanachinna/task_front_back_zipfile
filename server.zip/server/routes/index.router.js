const express = require('express');
const router = express.Router();

const ctrlUser = require('../controllers/user.controller');


router.post('/useradd', ctrlUser.useradd);
router.post('/userOrdecount', ctrlUser.userOrdecount);
router.post('/orderlist', ctrlUser.orderlist);
router.post('/userlist', ctrlUser.userlist);

router.post('/orderadd', ctrlUser.orderadd);
// router.post('/userOrdecount', ctrlUser.userOrdecount);

module.exports = router;




var a= [[{id:1}],[{id:2}]],var b=[];
for(var i=0;i<a.length;i++){
b.push(a[i]);

}console.log(b);

var stuff = {};
var stuff = [];
stuff.push(element);
stuff = {}; // Object

stuff['prop'] = 'value'; 
stuff.prop === stuff['prop'];

var obj = [{
    key1: 3,
    key2: 5
},{key1: 6777,
    key2: "value2"}];console.log(obj); for(var i=0;i<obj.length;i++){obj[i]["key4"]=78}console.log(obj,"2nd");
obj[0]["key3"] = "value3";console.log(obj,"2nd");

var jsObj = {
    "workbookInformation": {
        "version": "9.1",
        "source-platform": "win"
    },
    "datasources1": {

    },
    "datasources2": {

    }
};
jsObj["workbookInformation"]["NewPropertyName"] ="Value of New Property"; 
var json = JSON.stringify(jsObj);
 console.log(json)

 var arrOfObj = [{
  name: 'eve'
}, {
  name: 'john'
}, {
  name: 'jane'
}];

var result = arrOfObj.map(function(el) {
  var o = Object.assign({}, el);
  o.isActive = true;
  return o;
})

console.log(arrOfObj);
console.log(result);
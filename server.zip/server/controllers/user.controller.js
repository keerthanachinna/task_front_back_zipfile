const mongoose = require('mongoose');

const User = mongoose.model('User');
const Order = mongoose.model('Order');


module.exports.useradd = (req, res, next) => {
    var user = new User();
    user.userid = req.body.userid;
    user.name = req.body.name;
    user.save((err, doc) => {
        if (!err)
            res.send(doc);
        else return next(err);
    });
}
module.exports.orderadd = (req, res, next) => {
    var user = new Order();
    user.orderid = req.body.orderid;
    user.subtotal = req.body.subtotal;
    user.userid = req.body.userid;
    user.date = req.body.date;
    user.save((err, doc) => {
        if (!err)
            res.send(doc);
        else return next(err);
    });
}
module.exports.orderlist = (req, res, next) => {
    Order.find((err, doc) => {
        if (!err) res.send(doc);
        else { console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2)); }
    })
}
module.exports.userlist = (req, res, next) => {
    User.find((err, doc) => {
        if (!err) res.send(doc);
        else { console.log('Error in Retriving Employees :' + JSON.stringify(err, undefined, 2)); }
    })
}

module.exports.userOrdecount = async (req, res, next) => {
    try {
        let userlist1 = [];
        let userlist = [];
        userlist = await User.find();
        let userIDs = req.body.userid;
        let holesubtotal = [];
        let orderholecount = [];
        let userlistnew;
        let alllist1 = [];
        let alllist;
        let ordercount;
        let ordersum;
        for (var i = 0; i < userIDs.length; i++) {
            alllist = await Order.find({ userid: { $eq: userIDs[i] } });
            let ordersubtotal = allsubtotal(alllist);
            holesubtotal.push(ordersubtotal);
            ordercount = await Order.aggregate([{ $match: { userid: { $eq: userIDs[i] } } }, { $count: "userid" }]);
            orderholecount.push(ordercount);

        }

        for (var j = 0; j < orderholecount.length; j++) {
            userlistnew = orderholecount[j];
            // console.log("alllist..alllist1. userlist[j]", userlist[j]);
            // console.log("userlistnew[0].userid", userlistnew[0].userid);

            userlist[j].noOfOrders = userlistnew[0].userid;
            ordersum = holesubtotal[j] / userlistnew[0].userid;

            alllist1.push(ordersum);

        }
        // console.log("alllist..alllist1userlist.",userlist);
        for (var k = 0; k < userlist.length; k++) {
            userlist[k]["noOfOrders"] = "fgdhdgh";
            // userlist[k]["averageBillValue"]=3;

        }
        var data = { userlist, alllist, holesubtotal, orderholecount, userlistnew, alllist1 };
        return res.send(data);
    } catch (error) {
        console.log("error...", error);
    }
}

module.exports.userOrderupdare = async (req, res, next) => {
    try {
        let updateuser = await User.updateMany()
        return res.send(data);
    } catch (error) {
        console.log("error...", error);
    }
}


function allsubtotal(alllist) {
    if (alllist.length > 0) {
        let count, sum, samplecollectionIp;
        count = alllist.map(xop => {
            return sum = +xop.subtotal;
        });
        const reducer = (accumulator, currentValue) => accumulator + currentValue;
        samplecollectionIp = count.reduce(reducer);
        return samplecollectionIp;

    } else {
        return 0;
    };
}
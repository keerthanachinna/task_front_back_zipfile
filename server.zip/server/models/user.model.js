const mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    userid: {
        type: Number
    },
    name: {
        type: String
    },
    No_of_Orders: {type:Number,default:0}
});

mongoose.model('User', userSchema);
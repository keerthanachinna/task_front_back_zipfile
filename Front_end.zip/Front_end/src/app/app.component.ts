import { Component } from '@angular/core';
import { AppserviceService } from '../app/appservice.service';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

 
  tabledata: any = [];
  longgrzero: any = [];
  totalper: any;
  chartData: any = [];
  chart: any;
  chartDatafinal: any = [];
  longlesrzero: any = [];
  langgrzero: any = [];
  lanlegrzero: any = [];
  constructor(private apiService: AppserviceService) { }



  ngOnInit() {
    this.apiService.getData().subscribe((data) => {
      console.log(data);
      this.tabledata = data;
      let percentage = this.tabledata.length / 100;
      this.totalper = percentage * 100;

      for (var i = 0; i < this.tabledata.length; i++) {
        if (this.tabledata[i].address.geo.lat > 0) {
          this.chartData.push({
            'name': 'Latitude>0',
            'y': this.tabledata[i].address.geo.lat
          });
        }
        if (this.tabledata[i].address.geo.lat < 0) {
          this.chartData.push({
            'name': 'Latitude<0',
            'y': this.tabledata[i].address.geo.lat
          });
        }
        if (this.tabledata[i].address.geo.lng > 0) {
          this.chartData.push({
            'name': 'Longitude >0',
            'y': this.tabledata[i].address.geo.lat
          });
        }
        if (this.tabledata[i].address.geo.lng < 0) {
          this.chartData.push({
            'name': 'Longitude<0',
            'y': this.tabledata[i].address.geo.lat
          });
        }
      }
      for (var i = 0; i < this.chartData.length; i++) {
        if (this.chartData[i].name === "Longitude<0") {
          this.longgrzero.push(this.chartData[i]);
        }
        if (this.chartData[i].name === "Longitude >0") {
          this.longlesrzero.push(this.chartData[i]);
        }
        if (this.chartData[i].name === "Latitude<0") {
          this.langgrzero.push(this.chartData[i]);
        }
        if (this.chartData[i].name === "Latitude>0") {
          this.lanlegrzero.push(this.chartData[i]);
        }
      }

      this.chartDatafinal.push({
        'name': "Longitude<0",
        'y': this.longgrzero.length
      });
      this.chartDatafinal.push({
        'name': "Longitude >0",
        'y': this.longlesrzero.length
      });
      this.chartDatafinal.push({
        'name': "Latitude<0",
        'y': this.langgrzero.length
      });
      this.chartDatafinal.push({
        'name': "Latitude>0",
        'y': this.lanlegrzero.length
      });

      this.chart = new Chart({
        chart: {
          // type: 'area',
          backgroundColor: '#FFF',
          type: 'pie',
        },
        credits: {
          enabled: false
        },
        title: {
          useHTML: true,
          text: 'Pie chart'
        },
        subtitle: {
          text: ''
        },
        tooltip: {
          split: true,
        },
        plotOptions: {
          area: {
            // stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
              lineWidth: 1,
              lineColor: '#666666'
            }
          }
        },
        series: [{
          type: 'pie',
          data: this.chartDatafinal
        }],
      })
    });
  };
}
